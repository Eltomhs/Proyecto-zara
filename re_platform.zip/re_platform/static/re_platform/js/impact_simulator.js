// Simulador de Impacto Ambiental (modo demo)
document.addEventListener("DOMContentLoaded", () => {
  const envioSelect = document.getElementById("envioSelect");
  const materialSelect = document.getElementById("materialSelect");
  const co2Value = document.getElementById("co2Value");
  const aguaValue = document.getElementById("aguaValue");
  const message = document.getElementById("impactMessage");

  const baseCO2 = 12.5;
  const baseAgua = 250;

  function actualizarImpacto() {
    let co2 = baseCO2;
    let agua = baseAgua;

    if (envioSelect.value === "lento") co2 -= 2.5;
    if (materialSelect.value === "reciclada") {
      co2 -= 4;
      agua -= 70;
    }

    // Animación suave del número
    animateNumber(co2Value, co2);
    animateNumber(aguaValue, agua);

    const ahorroCO2 = (baseCO2 - co2).toFixed(1);
    const ahorroAgua = (baseAgua - agua).toFixed(0);

    message.innerHTML = `
      Tu elección ahorra <strong>${ahorroCO2} kg de CO₂</strong> 
      y <strong>${ahorroAgua} L de agua</strong> 🌿
    `;
  }

  function animateNumber(element, newValue) {
    const current = parseFloat(element.textContent);
    const diff = newValue - current;
    const steps = 20;
    let i = 0;
    const interval = setInterval(() => {
      i++;
      element.textContent = (current + (diff * i) / steps).toFixed(1);
      if (i >= steps) clearInterval(interval);
    }, 25);
  }

  envioSelect.addEventListener("change", actualizarImpacto);
  materialSelect.addEventListener("change", actualizarImpacto);
});
