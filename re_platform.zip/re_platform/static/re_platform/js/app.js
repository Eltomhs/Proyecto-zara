// Pequeño script genérico (placeholder)
document.addEventListener("DOMContentLoaded", () => {
  console.log("RE_ base cargada correctamente");
});
document.addEventListener("DOMContentLoaded", () => {
  console.log("RE_ base cargada correctamente");

  const tabs = document.querySelectorAll(".tab");
  const panels = {
    tutoriales: document.getElementById("tab-tutoriales"),
    talleres: document.getElementById("tab-talleres"),
    retos: document.getElementById("tab-retos"),
  };

  tabs.forEach(btn => {
    btn.addEventListener("click", () => {
      // estado visual de tabs
      tabs.forEach(b => b.classList.remove("is-active"));
      btn.classList.add("is-active");

      // mostrar panel correspondiente
      Object.values(panels).forEach(p => p.classList.add("is-hidden"));
      const key = btn.dataset.tab;
      panels[key].classList.remove("is-hidden");

      // accesibilidad básica
      tabs.forEach(b => b.setAttribute("aria-selected", b === btn ? "true" : "false"));
    });
  });
});
document.addEventListener("DOMContentLoaded", () => {
  const track = document.getElementById("storiesTrack");
  if (!track) return;

  const by = 260; // px por “card”
  document.querySelectorAll(".stories-ctrl .btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const dir = btn.dataset.act === "next" ? 1 : -1;
      track.scrollBy({ left: dir * by, behavior: "smooth" });
    });
  });
});
document.addEventListener("DOMContentLoaded", () => {
  const track = document.getElementById("storiesTrack");
  if (!track) return;

  const by = 260; // px por “card”
  document.querySelectorAll(".stories-ctrl .btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const dir = btn.dataset.act === "next" ? 1 : -1;
      track.scrollBy({ left: dir * by, behavior: "smooth" });
    });
  });
});
document.addEventListener("DOMContentLoaded", () => {
  // Toggle visual de chips (no calcula nada aún)
  document.querySelectorAll(".eco-choices .chip").forEach(chip => {
    chip.addEventListener("click", () => chip.classList.toggle("is-on"));
  });
});
document.addEventListener("DOMContentLoaded", () => {
  const q = document.getElementById("qCity");
  const list = document.getElementById("pointsList");
  if (!q || !list) return;

  q.addEventListener("input", () => {
    const term = q.value.trim().toLowerCase();
    list.querySelectorAll(".point").forEach(li => {
      const city = (li.dataset.city || "").toLowerCase();
      const text = li.textContent.toLowerCase();
      const match = !term || city.includes(term) || text.includes(term);
      li.style.display = match ? "" : "none";
    });
  });
});
document.addEventListener("DOMContentLoaded", () => {
  // Toggle de modo de identificación (qr / orden / manual)
  const idRadios = document.querySelectorAll('input[name="id_mode"]');
  const idPanels = document.querySelectorAll(".id-panel");
  const showPanel = (mode) => {
    idPanels.forEach(p => p.classList.toggle("is-hidden", p.dataset.mode !== mode));
  };
  idRadios.forEach(r => r.addEventListener("change", () => showPanel(r.value)));
  showPanel(document.querySelector('input[name="id_mode"]:checked')?.value || "qr");

  // Cotización: suma servicios + cargo rápido (si quieres fija, aquí demo con 0)
  const money = n => `$${n.toLocaleString("es-CL")}`;
  const svcs = document.querySelectorAll(".svc");
  const sumServices = document.getElementById("sumServices");
  const sumSubtotal = document.getElementById("sumSubtotal");
  const sumFast = document.getElementById("sumFast");
  const sumTotal = document.getElementById("sumTotal");
  const accept = document.getElementById("accept");
  const bookBtn = document.getElementById("bookBtn");

  function recalc() {
    let items = [];
    let subtotal = 0;
    svcs.forEach(chk => {
      if (chk.checked) {
        const name = chk.dataset.name;
        const price = Number(chk.dataset.price || 0);
        subtotal += price;
        items.push({ name, price });
      }
    });

    // pintar lista
    sumServices.innerHTML = items.length
      ? items.map(i => `<li><span>${i.name}</span><span>${money(i.price)}</span></li>`).join("")
      : `<li class="muted">Aún no seleccionas servicios</li>`;

    // cargo rápido demo = 0 (puedes cambiarlo si quieres)
    const fast = 0;
    sumSubtotal.textContent = money(subtotal);
    sumFast.textContent = money(fast);
    sumTotal.textContent = money(subtotal + fast);

    // habilitar botón si hay servicios y acepta términos
    bookBtn.disabled = !(items.length && accept.checked);
  }

  svcs.forEach(chk => chk.addEventListener("change", recalc));
  accept?.addEventListener("change", recalc);
  recalc();

  // Visual de chips (pickup/store/locker)
  document.querySelectorAll(".chip-toggle input").forEach(input => {
    input.addEventListener("change", () => {
      document.querySelectorAll('.chip-toggle input[name="'+input.name+'"]').forEach(i => {
        i.parentElement.classList.toggle("is-on", i.checked);
      });
    });
    // estado inicial
    input.parentElement.classList.toggle("is-on", input.checked);
  });
});
document.addEventListener("DOMContentLoaded", () => {
  // 1) Switch de identificación
  const idRadios = document.querySelectorAll('input[name="id_mode"]');
  const idPanels = document.querySelectorAll(".id-panel");
  const showPanel = (mode) => {
    idPanels.forEach(p => p.classList.toggle("is-hidden", p.dataset.mode !== mode));
  };
  idRadios.forEach(r => r.addEventListener("change", () => showPanel(r.value)));
  showPanel(document.querySelector('input[name="id_mode"]:checked')?.value || "qr");

  // 2) Visual chips toggles
  document.querySelectorAll(".chip-toggle input").forEach(input => {
    input.addEventListener("change", () => {
      document.querySelectorAll('.chip-toggle input[name="'+input.name+'"]').forEach(i => {
        i.parentElement.classList.toggle("is-on", i.checked);
      });
    });
    input.parentElement.classList.toggle("is-on", input.checked);
  });

  // 3) Precargar datos demo al elegir manual
  const preset = document.getElementById("demoPreset");
  const btnPreload = document.getElementById("btnPreload");
  const title = document.getElementById("title");
  const size = document.getElementById("size");
  const fabric = document.getElementById("fabric");
  const desc = document.getElementById("desc");
  const prevImg = document.getElementById("prevImg");
  const prevTitle = document.getElementById("prevTitle");
  const prevSubtitle = document.getElementById("prevSubtitle");

  const DEMO = {
    chaqueta: {
      title: "Chaqueta RE_ Mocha",
      size: "M",
      fabric: "Algodón · Reciclado 55%",
      desc: "Pocas usadas. Conserva forma y color. Incluye botón de repuesto.",
      img: null
    },
    sweater: {
      title: "Sweater Gardenia",
      size: "S",
      fabric: "Algodón orgánico",
      desc: "Suave y cómodo. Sin bolitas. Muy poco uso.",
      img: null
    },
    pantalon: {
      title: "Pantalón Tendril",
      size: "38",
      fabric: "Lino reciclado 40%",
      desc: "Entallado, dobladillo recién hecho.",
      img: null
    }
  };

  btnPreload?.addEventListener("click", () => {
    const k = preset?.value || "chaqueta";
    const d = DEMO[k];
    title.value = d.title;
    size.value = d.size;
    fabric.value = d.fabric;
    desc.value = d.desc;
    prevTitle.textContent = d.title;
    prevSubtitle.textContent = `${d.size} · ${d.fabric}`;
    if (d.img) prevImg.src = d.img;
  });

  // 4) Estimador de precio (vincular slider y número + preview)
  const priceInput = document.getElementById("price");
  const slider = document.getElementById("slider");
  const prevPrice = document.getElementById("prevPrice");
  const fmt = n => `$${Number(n||0).toLocaleString("es-CL")}`;

  function syncPrice(from) {
    if (from === "slider") priceInput.value = slider.value;
    else slider.value = priceInput.value || slider.min;
    prevPrice.textContent = fmt(priceInput.value);
  }
  priceInput?.addEventListener("input", () => syncPrice("input"));
  slider?.addEventListener("input", () => syncPrice("slider"));
  syncPrice("input");

  // 5) Estado -> badge en preview
  const condition = document.getElementById("condition");
  const prevCond = document.getElementById("prevCond");
  condition?.addEventListener("change", () => prevCond.textContent = condition.value);

  // 6) Usar contenido oficial (demo: sólo mensaje visual)
  const useOfficial = document.getElementById("useOfficial");
  useOfficial?.addEventListener("change", () => {
    // Aquí luego podrías bloquear edición y forzar fotos oficiales
    console.log("Usar contenido oficial:", useOfficial.checked);
  });

  // 7) Publicar (demo)
  const publishBtn = document.getElementById("publishBtn");
  publishBtn?.addEventListener("click", () => {
    alert("Demo: anuncio listo para publicar (sin enviar datos).");
  });
});
document.addEventListener("DOMContentLoaded", () => {
  // Filtros básicos del historial (demo sin backend)
  const fType = document.getElementById("fType");
  const fPeriod = document.getElementById("fPeriod");
  const tbody = document.getElementById("historyBody");

  function applyFilters() {
    const type = (fType?.value || "").trim();
    // Nota: fPeriod no filtra realmente fechas en demo; se deja hook para backend.
    Array.from(tbody?.rows || []).forEach(tr => {
      const okType = !type || tr.dataset.type === type;
      tr.style.display = okType ? "" : "none";
    });
  }

  fType?.addEventListener("change", applyFilters);
  fPeriod?.addEventListener("change", applyFilters);
  applyFilters();
});
