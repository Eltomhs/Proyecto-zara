from django.apps import AppConfig


class RePlatformConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 're_platform'
