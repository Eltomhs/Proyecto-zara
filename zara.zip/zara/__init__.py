default_app_config = "zara.apps.ZaraConfig"
