from django.contrib import admin
from .models import (
    Perfil, Direccion, Producto, Cupon,
    Carrito, ItemCarrito, Pedido,
    CampaniaEncuesta, RespuestaEncuesta
)

@admin.register(Perfil)
class PerfilAdmin(admin.ModelAdmin):
    list_display = ("user", "rol", "nombre_mostrar", "creditos_circulares", "nivel", "tema")
    list_filter = ("rol", "tema")
    search_fields = ("user__username", "user__email", "nombre_mostrar")

@admin.register(Direccion)
class DireccionAdmin(admin.ModelAdmin):
    list_display = ("user", "alias", "ciudad", "region", "pais", "es_principal")
    list_filter = ("pais", "es_principal")
    search_fields = ("user__username", "ciudad", "alias")

class ItemCarritoInline(admin.TabularInline):
    model = ItemCarrito
    extra = 0

@admin.register(Carrito)
class CarritoAdmin(admin.ModelAdmin):
    list_display = ("id", "cupon", "creado_en", "actualizado_en")
    inlines = [ItemCarritoInline]

@admin.register(Producto)
class ProductoAdmin(admin.ModelAdmin):
    list_display = ("nombre", "precio", "stock")
    search_fields = ("nombre",)

@admin.register(Cupon)
class CuponAdmin(admin.ModelAdmin):
    list_display = ("codigo", "descuento_porcentaje", "vigente_desde", "vigente_hasta", "activo")
    list_filter = ("activo",)

@admin.register(Pedido)
class PedidoAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "email_cliente", "estado", "total_pagado", "creado_en")
    list_filter = ("estado", "creado_en")
    search_fields = ("email_cliente", "user__username")

@admin.register(CampaniaEncuesta)
class CampaniaEncuestaAdmin(admin.ModelAdmin):
    list_display = ("nombre", "activa")

@admin.register(RespuestaEncuesta)
class RespuestaEncuestaAdmin(admin.ModelAdmin):
    list_display = ("campania", "email", "rating_sustentabilidad", "rating_calidad", "enviado_en")
    list_filter = ("campania",)
